const mongoose = require("mongoose");
mongoose.Promise = require("bluebird");

const url = 'mongodb+srv://chrishughes:Boston12@cluster0-b85ug.azure.mongodb.net/test?retryWrites=true&w=majority'

const connect = mongoose.connect(url, { useNewUrlParser: true });

module.exports = connect;
