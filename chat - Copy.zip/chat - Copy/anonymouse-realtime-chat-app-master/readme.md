
## Installation

> Clone this repository and run

```bash
npm install

```

Then run:

```bash
npm start
```

goto your browser

and visit localhost:5000 and start chatting.

Note:

You should have mongoDB installed and started for this application to work correctly.
